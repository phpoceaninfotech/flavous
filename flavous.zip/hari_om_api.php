<?php

include('root/config.php');
//$url='http://lionaircompressor.com/';
if(!isset($_POST['action']))
{
  	$arr['status']='Error Action';
  	$arr['message']='Input Proper Data';

  	header("Content-Type:application/json");
  	header("Transfer-Encoding:chunked");
  	echo json_encode($arr);
  	exit;
}



else
	
 	switch ($_POST['action'])
 	{  
    	
 		case 'user_login':
			
		    if(isset($_POST['molie_number'])) { 

          		$molie_number = $_POST['molie_number'];
		    		
	    		$select_query =  mysqli_query($ai_conn,"SELECT * FROM `tab_user` where user_molie_number='$molie_number'");
				if(mysqli_num_rows($select_query)>0) {

					$row = mysqli_fetch_array($select_query);
					if($row['status']==0){
						$user_paid_and_free = $row['user_paid_and_free'];
						if ($user_paid_and_free==1) {
							/*$fetch['free'] = "FREE";*/
							$fetch['status'] = "Success";
        			        $fetch['message'] = "Successfully Login";
        			        $fetch['user_id'] = ''.$row['id'].'';
						}else{
							/*$fetch['paid'] = "PAID";*/
							$fetch['status'] = "Success";
	                        $fetch['message'] = "Successfully Login";
	                        $fetch['user_id'] = ''.$row['id'].'';
				        }
		        	}
		        	else{
		        		$fetch['status'] = "Error";
            			$fetch['message'] = "Sorry you are Blocked";
		        	}
				}
				else{
					$date = date('Y-m-d');
					$end_date=date_create("$date");
					date_add($end_date,date_interval_create_from_date_string("5 days"));
					$date_format = date_format($end_date, 'd-m-Y');
    						
					$query = "INSERT INTO `tab_user`(`user_molie_number`, `user_paid_and_free`, `doi`, `status`) VALUES ('$molie_number','1','$date_format','0')";
					$insert_query = mysqli_query($ai_conn,$query);
				    if($insert_query) {
				      	$last_id = mysqli_insert_id($ai_conn);
			          	$fetch['status'] = "Success";
			          	$fetch['message'] = "Successfully Inserted"; 
			          	$fetch['user_id']=''.$last_id.'';
				    }
				    else{
				      	$fetch['status'] = "Error";
			    	    $fetch['message'] = "Failed to Insert";
			      	}
				}
	    	}
	    	else {
          		$fetch['status'] = "Error";
          		$fetch['message'] = "Parameter is Required";
	        }
		header("Content-Type:application/json");
	    echo json_encode($fetch);
	    break;


	    case 'slider':
			
		    $select_query =  mysqli_query($ai_conn,"SELECT * FROM `tbl_slider`  ORDER BY `id` ASC");
			if(mysqli_num_rows($select_query)>0) {
				$arr = [];
				while($row = mysqli_fetch_assoc($select_query))
				{
					$id = $row['id'];
	                       
					$arr[] = array(
						'id' => $row['id'],
						'title' => $row['title'],
						'image' => $row['image']=$url."slider/".$row['image'],
					);
				}		
				$fetch['slider'] = $arr;
				$fetch['status'] = 'success';
				$fetch['message'] = "Successfully";
			}
			else
			{
				$fetch['status'] = 0;
				$fetch['message'] = "No record available";
			}
		header("Content-Type:application/json");
		echo json_encode($fetch);
		break;
		

	case 'get_employee':
			
		    $select_query =  mysqli_query($ai_conn,"SELECT * FROM `tbl_employee` WHERE status='active'");
			if(mysqli_num_rows($select_query)>0) {
				$arr = [];
				while($row = mysqli_fetch_assoc($select_query))
				{
					$id = $row['id'];
	                       
					$arr[] = array(
						'id' => $row['id'],
						'name' => $row['name'],
						'number' => $row['number'],
					);
				}		
				$fetch['get_employee'] = $arr;
				$fetch['status'] = 'success';
				$fetch['message'] = "Successfully";
			}
			else
			{
				$fetch['status'] = 0;
				$fetch['message'] = "No record available";
			}
		header("Content-Type:application/json");
		echo json_encode($fetch);
		break;
		
		
		case 'complain_add':
			
		    if(isset($_POST['party_name']) && isset($_POST['party_mo']) && isset($_POST['address']) && isset($_POST['fault']) && isset($_POST['employee_id'])) { 

		        $party_name = $_POST['party_name'];
	    		$party_mo = $_POST['party_mo'];
	    		$address = $_POST['address'];
	    		$fault = $_POST['fault'];
	    		$employee_id = $_POST['employee_id'];
	    		
			    		
	    		$query = "INSERT INTO `tbl_complain`(`party_name`, `party_mo`, `address`, `fault`, `employee_id`, `status`) VALUES ('$party_name', '$party_mo', '$address', '$fault', '$employee_id', 'pending')";
				                  
		        $insert_query = mysqli_query($ai_conn,$query);
            	if($insert_query) {
            		$last_id = mysqli_insert_id($ai_conn);
            		$fetch['complain_id'] = "".$last_id.""; 
            		$fetch['status'] = "Success";
        			$fetch['message'] = "Successfully Inserted"; 
        		}else { 
            		$fetch['status'] = "Error";
              		$fetch['message'] = "Failed to Insert"; 
            	}
			}else {
	         	$fetch['status'] = "Error";
	          	$fetch['message'] = "Parameter is Required";
	        }
		header("Content-Type:application/json");
	    echo json_encode($fetch);
	    break;
	

		default:
		
		$fetch['status']='Error';
		$fetch['message']='Enter Correct Category';
		header("Content-Type:application/json");
		header("transfer-encoding:chunked");
		echo json_encode($fetch);
		break;
	}
	

?>
