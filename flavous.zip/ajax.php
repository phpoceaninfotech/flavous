<?php

include 'root/config.php';
if (!isset($_POST['action'])) {
    echo '';
    exit;
}
if ($_POST['action'] == 'login') {
    $loginUname = addslashes($_POST['loginUname']);
    $loginPassword = md5($_POST['loginPassword']);
    $qry = "SELECT * FROM " . DB_PREFIX . "admin WHERE  username='".$loginUname."' AND password='".$loginPassword."' ";
    $row = $ai_db->aiGetQuery($qry);
    if (count($row)) {
        foreach ($row as $user) {
            if ($loginPassword == $user['password']) {
                if ($user['is_active'] == '1') {
                    $_SESSION['aid'] = $user['id'];
                    $_SESSION['login_type'] = "ADMIN";
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['username'] = $user['username'];
                    $data = "success";
                } else {
                    $data = "not active";
                }
            }
        }
    } else {
        
        $qry1 = "SELECT * FROM " . DB_PREFIX . "distributor WHERE username='".$loginUname."'";
        $row1 = $ai_db->aiGetQuery($qry1);
        if (count($row1)) {
            foreach ($row1 as $user1) {
                if ($loginPassword == $user1['passmd5']) {
                    if ($user1['status'] == 'active') {
                        $_SESSION['aid'] = $user1['id'];
                        $_SESSION['login_type'] = "distributor";
                        $_SESSION['email'] = $user1['email'];
                        $_SESSION['username'] = $user1['username'];
                        $data = "success";
                    } else {
                        $data = "not active";
                    }
                }

            }
            
        } else {
            $data = "not found";
        }
    }
    echo $data;
}
if ($_POST['action'] == 'check-password') {
    $OldPassword = md5($_POST['old_pass']);
    $qry = "SELECT * FROM " . DB_PREFIX . "admin WHERE password='" . $OldPassword . "' AND id=" . $_SESSION['aid'];
    $result = $ai_db->aiGetQueryObj($qry);
    if (empty($result)) {
        echo 'fail';
    } else {
        echo 'success';
    }
}
