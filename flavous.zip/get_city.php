<?php 
    include('root/config.php');
    
    $city_id = $_REQUEST['city_id'];
    
    $qrys = "SELECT * FROM tbl_city WHERE status='active' AND state_id='$city_id' ORDER BY id ASC";
	$rows = $ai_db->aiGetQueryObj($qrys);
	foreach($rows as $mcrow){
	    echo '<option value="'.$mcrow->id.'">'.$mcrow->name.'</option>';
 } ?>